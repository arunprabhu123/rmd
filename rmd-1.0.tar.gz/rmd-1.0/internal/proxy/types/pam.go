package types

// PAMRequest is request from rpc client
type PAMRequest struct {
	User string
	Pass string
}
