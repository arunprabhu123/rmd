#!/bin/sh -xe

rm -rf /usr/local/sbin/rmd
