// +build integrationHTTPS

package integrationHTTPS

import (
	. "github.com/onsi/ginkgo"
)

var _ = Describe("CertAuth", func() {
})
